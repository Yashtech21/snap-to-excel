# Snap to Excel

Chrome extension (Manifest V3). One click captures the page (or a fixed area), uploads the PNG to
OneDrive/SharePoint and adds a row with a link to an Excel table. No backend, no build step.

## Load it locally
1. Open `chrome://extensions`, turn on **Developer mode**.
2. **Load unpacked** and pick this folder. Settings open automatically.
3. Copy the **Redirect URI** shown in Settings (looks like `https://<extension-id>.chromiumapp.org/`).

## Register the Microsoft app (once, free)
1. Go to entra.microsoft.com → **App registrations** → **New registration**.
2. Supported account types: your organization only, or work/school + personal, as you prefer.
3. Under **Authentication** → **Add a platform** → **Single-page application**, paste the Redirect URI.
4. Under **API permissions** add Microsoft Graph **Delegated**: `Files.ReadWrite.All`, `User.Read`
   (`offline_access`, `openid`, `profile` are added automatically). Grant admin consent if your tenant requires it.
5. Copy the **Application (client) ID** into the extension Settings. No client secret is needed or used.

Note: the extension ID changes if you load it unpacked from a different folder. Once published, the Web Store
ID is fixed, so add that final Redirect URI to the app registration too. Refresh tokens issued to
single-page apps expire after about 24 hours of inactivity, so you may be asked to sign in again now and then.

## Use it
1. Settings → paste the workbook link (Excel → Share → **Copy link**) → **Set up destination**.
   This creates the worksheet and table if missing. Existing tables work too: columns are matched by header name
   (`Screenshot`, `Timestamp`, `Page Title`, `Page URL`, `File Name`); other columns are left blank.
2. Open any website, click the toolbar icon, turn on **Show button on this site**, and allow the permission.
3. Click the floating camera button (drag it anywhere) or press **Alt+Shift+S**.
4. Optional: **Set fixed area on this page** to always capture the same rectangle.

Failed uploads stay in a local queue and retry every minute. Identical captures within the chosen window are skipped.

## Permissions (why)
| Permission | Reason |
|---|---|
| `activeTab`, `scripting` | Capture the current tab and read its title/URL when you use the shortcut or popup |
| `storage`, `alarms` | Settings and background retry of queued uploads |
| `identity` | Microsoft sign-in window |
| `notifications` | Status messages on pages without the floating button |
| Hosts: `graph.microsoft.com`, `login.microsoftonline.com` | Microsoft Graph and sign-in |
| Optional hosts | Requested per site, only when you turn the button on |

## Publish to the Chrome Web Store
1. Zip the folder contents (`manifest.json` at the zip root).
2. Create a developer account (one-time fee) at the Chrome Web Store Developer Dashboard and upload the zip.
3. Provide: a single-purpose description ("Save screenshots to Excel"), screenshots (1280×800), a privacy policy URL, and a
   justification for each permission (table above).
4. Privacy policy points: data stays on the device until uploaded to the user's own Microsoft 365 location; no analytics,
   no third-party servers; refresh token encrypted locally; users can sign out and delete all data in Settings.

## Files
- `src/background/service-worker.js` – capture flow, queue, messaging
- `src/lib/` – `auth` (Entra PKCE), `graph` (upload + Excel), `pipeline` (retry queue), `capture` (crop/hash), `secure` (encryption), `db`, `settings`
- `src/content/` – floating button and area picker
- `popup/`, `options/` – UI
